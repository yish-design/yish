<section class="portfolio" id="portfolio">
    <div class="portfolio-margin">
        <h1 class="title">案例</h1>
        <h1 class="title-en">WORKS</h1>
        <hr />
        <!-- 1 item portoflio-->
        <ul class="grid" id="case-index-data">
            <?php if ($fn_include = $this->_include("index_data.html")) include($fn_include); ?>
        </ul>

        <a href="javascript:void(0);" id="loadMoreData">
            <div class="read-more">
                Read more <div class="loaddata" style="display: none"><i></i></div>
            </div>

        </a>
    </div>
</section>
<style>

</style>