<section class="partners parallax-background-partners" id="partners">
    <div class="opacity"></div>
    <div class="content">
        <h2></h2>

    </div>
</section>