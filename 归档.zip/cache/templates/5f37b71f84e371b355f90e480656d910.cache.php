<section class="start-page parallax-background" id="home">
    <div class="opacity"></div>
    <!-- Opacity color -->
    <div class="content">
        <div class="text">
            <div class="logo">
                <img src="<?php echo HOME_THEME_PATH; ?>build/img/logo.png" />
            </div>
            <h1>YISH DESIGN</h1>
            <hr />
            <p>Design for the Real World.</p>
            <a href="#about-us">
                <div class="read-more">
                    Read more
                </div></a>
        </div>
        <div class="arrow-down"></div>
    </div>
</section>