<section class="footer">
    <div class="logo">
        YISH DESIGN
    </div>
    <div class="menu-footer">
        <a href="#home">Home</a>
        <a href="#">About us</a>
        <a href="#">Portfolio</a>
        <a href="#">Contact</a>
    </div>
    <div class="copyright">
        &copy; 2016. All Rights Reserved yish-design.com
    </div>
</section>