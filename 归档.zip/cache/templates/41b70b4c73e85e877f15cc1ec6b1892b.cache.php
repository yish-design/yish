<div class="dr_footer"><?php echo $this->ci->get_system_run_info(); ?></div>
</body>
</html>