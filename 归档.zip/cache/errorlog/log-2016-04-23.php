<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-23 18:54:10 --> Severity: Parsing Error --> syntax error, unexpected '}' /Users/julaud/www/php/mantou/mantob/cache/templates/f554edec5e4c677f360885b73eccd0c5.cache.php 21
ERROR - 2016-04-23 23:37:36 --> Severity: Parsing Error --> syntax error, unexpected end of file /Users/julaud/www/php/mantou/mantob/cache/templates/f53272f22cb94792955bfc0e6575ada3.cache.php 216
