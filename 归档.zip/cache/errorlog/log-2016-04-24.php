<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-24 11:23:17 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting variable (T_VARIABLE) or '$' /Users/julaud/www/php/mantou/mantob/cache/templates/25e5c516b1d4d94b48308b692fa39f41.cache.php 78
