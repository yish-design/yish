<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-28 13:06:17 --> Severity: Parsing Error --> syntax error, unexpected end of file /Users/julaud/www/php/mantou/mantob/cache/templates/f554edec5e4c677f360885b73eccd0c5.cache.php 69
