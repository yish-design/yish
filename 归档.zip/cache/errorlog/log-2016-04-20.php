<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-20 12:02:37 --> Severity: Error --> Call to a member function dbprefix() on null /Users/julaud/www/php/mantou/mantob/mantob/core/D_Common.php 204
ERROR - 2016-04-20 13:17:23 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:19:14 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:19:26 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:19:34 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:19:42 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:19:55 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 13:23:41 --> Severity: Error --> Call to a member function dbprefix() on null /Users/julaud/www/php/mantou/mantob/mantob/core/D_Common.php 204
ERROR - 2016-04-20 13:57:21 --> Severity: Parsing Error --> syntax error, unexpected '}' /Users/julaud/www/php/mantou/mantob/cache/templates/0a72d9e97b1c67c5765cd002fac11377.cache.php 25
ERROR - 2016-04-20 13:58:17 --> Severity: Parsing Error --> syntax error, unexpected '}' /Users/julaud/www/php/mantou/mantob/cache/templates/0a72d9e97b1c67c5765cd002fac11377.cache.php 25
ERROR - 2016-04-20 15:49:48 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:12:47 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:23:02 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:23:57 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:24:08 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:24:26 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:24:38 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 16:24:47 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 17:46:59 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 17:47:19 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 17:47:31 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
ERROR - 2016-04-20 19:04:59 --> 钩子调用文件（/Users/julaud/www/php/mantou/mantob/mantob/hooks/module_hooks.php）的不存在
