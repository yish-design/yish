<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-01 10:38:14 --> Severity: Compile Error --> require(): Failed opening required 'E:\wwwroot\wubu.com\omooo/core/D_Common.php' (include_path='.;C:\php\pear') E:\wwwroot\wubu.com\mantob\core\M_Controller.php 14
