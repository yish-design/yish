<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-22 11:23:46 --> Query error: Unknown column 'imgmain' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:24:45 --> Query error: Unknown column 'imgbg' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:24:58 --> Query error: Unknown column 'mp4' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:25:08 --> Query error: Unknown column 'flv' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:25:18 --> Query error: Unknown column 'webm' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:25:27 --> Query error: Unknown column 'ogv' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
ERROR - 2016-04-22 11:25:35 --> Query error: Unknown column 'css' in 'field list' - Invalid query: UPDATE `man_1_navigator` SET `pid` = '0', `url` = 'http://', `name` = '1', `title` = '', `description` = 'asd', `thumb` = '', `imgmain` = NULL, `imgbg` = '', `mp4` = '', `flv` = '', `webm` = '', `ogv` = '', `words` = '23213333', `css` = NULL, `extend` = 0
WHERE `id` = 1
