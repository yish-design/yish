<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-12 18:58:27 --> Unable to select database: man_1
