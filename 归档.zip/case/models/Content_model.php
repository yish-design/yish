<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

 /**
 * mantob Website Management System
 *
 * @since		version 2.0.1
 * @author		mantob <mantob@gmail.com>
 * @license     http://www.mantob.com/license
 * @copyright   Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

require FCPATH.'mantob/core/C_Model.php';
 
class Content_model extends C_Model {

	/*
	 * 构造函数
	 */
    public function __construct() {
        parent::__construct();
    }
	
}