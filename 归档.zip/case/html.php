<?php

// 用于多站点生成静态时的网站入口文件

require dirname(dirname(dirname(__FILE__))).'/index.php';
