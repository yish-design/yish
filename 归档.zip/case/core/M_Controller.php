<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Omweb Website Management System
 *
 * @since		version 2.0.0
 * @author		mantob <kefu@mantob.com>
 * @license     http://www.mantob.com/license
 * @copyright   Copyright (c) 2013 - 9999, mantob.Com, Inc.
 * @filesource	svn://www.mantob.com/v2/news/core/M_Controller.php
 */
	
require FCPATH.'mantob/core/D_Module.php';

class M_Controller extends D_Module {

    /**
     * 构造函数继承公共Module类
     */
    public function __construct() {
        parent::__construct();
    }
	
}