<?php

return array(

	'MAN_NAME'		=> ' 全能版',
	'MAN_UPDATE'		=> '2016.3.02',
	'MAN_VERSION'	=> '1.0.6',
	'MAN_VERSION_ID'	=> 19

);