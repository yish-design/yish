<?php

/**
 * Omweb Website Management System
 * 
 * @since			version 1.0.6
 * @author			mantob <kefu@mantob.com>
 * @license     	http://www.mantob.com/license
 * @copyright		Copyright (c) 2013 - 9999, mantob.Com, Inc.
 */

/**
 * 站点域名文件
 */

return array(

	'yish.app'                      => 1,

);